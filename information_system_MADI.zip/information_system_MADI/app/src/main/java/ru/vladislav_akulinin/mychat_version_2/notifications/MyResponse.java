package ru.vladislav_akulinin.mychat_version_2.notifications;

public class MyResponse {

    public int success;

}
