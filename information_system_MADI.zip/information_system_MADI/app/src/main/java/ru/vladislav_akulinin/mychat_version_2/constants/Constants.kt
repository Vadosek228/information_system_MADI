package ru.vladislav_akulinin.mychat_version_2.constants

class Constants {
    val STORAGE_PATH_UPLOADS = "uploads/"
    val DATABASE_PATH_UPLOADS = "uploads"
}