package ru.vladislav_akulinin.mychat_version_2.model

data class ChatListModel(
        var id: String? = null
) {
    constructor() :this("")
}