package ru.vladislav_akulinin.mychat_version_2.ui.base

class BaseFragment {
}